
public class ClickPiece {
	
	private void generatePage(Case c){
		
	}
	
	private void clickableGraphicOnCase(){
		
	}
	
	private void showCase(){
		
	}
	
	private boolean detectClick(){
		// From web page
		return false;
		
	}
	
	
}
